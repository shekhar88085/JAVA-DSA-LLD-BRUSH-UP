package JAVA.walmart.user;

public class User {

}
