package JAVA.walmart;

public interface Game {

}
